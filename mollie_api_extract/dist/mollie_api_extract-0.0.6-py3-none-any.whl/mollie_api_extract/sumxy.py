def my_sum(x, y):     
    """calculates the sum of x and y.     
    Parameters:     
       x (int): a number
       y (int): another number    
    Returns:     
       int: sum of x and y
    """         
    return(x+y)


